import json, sqlite3, pathlib, re
from decimal import Decimal, ROUND_HALF_UP

BASE = pathlib.Path(__file__).resolve().parents[1]
OUT = pathlib.Path(__file__).resolve().parent
raw = json.loads((BASE/'collection/published-book-statistics.json').read_text())
categories = json.loads((BASE/'raw/categories.json').read_text())
cats = {x['id']:x for x in categories}
parents = {x['parent_id'] for x in categories}
versions = {x['id']:x for x in json.loads((BASE/'raw/versions.json').read_text())}
inventory = json.loads((BASE/'collection/source-inventory.json').read_text())
def ancestry(i):
    result=[]
    while i in cats:
        result.insert(0,cats[i]); i=cats[i]['parent_id']
    return result
def cents(v): return int((Decimal(str(v))*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
def slug(s):return re.sub('[^a-z0-9]+','_',s.lower()).strip('_')
aliases={'Mayor (Executive)':'Executive Office','Executive':'Executive Office','Treasury':'Treasurer/Collector','Legislature':'Legislative','Finance':'Finance/Procurement','Assessing':'Assessor','Solicitor (Law)':'Law','Clerk':'City Clerk','Elections Department':'Elections','Cable (PEG) Department':'Medford Community Media','Cable':'Medford Community Media','Building Maintence':'Building Maintenance','School':'Medford Public Schools','Diversity':'Diversity, Equity & Inclusion','Civil Defense':'Emergency Management','Health':'Health and Human Services','Worker Compensation':"Workers Compensation"}
expense_names={'Personnel','Personnel Expenses','Ordinary Expenses','Other Financing','Capital'}
def mapping(d):
    chain=ancestry(d); names=[x['name'] for x in chain]
    if d==1088660:return ('Revenue','Revenue','Revenue','Revenue')
    meaningful=[x for x in chain[1:] if x['name'] not in expense_names]
    if not meaningful:return ('Unclassified','Unclassified','Unclassified','Unclassified')
    group=meaningful[0]['name']
    # Retain subprograms such as Veteran Celebrations, and PDS/Planning separately.
    department=meaningful[-1]['name']
    function=next((n for n in reversed(names) if n in expense_names),'Other')
    if function=='Personnel':function='Personnel Expenses'
    return group,department,aliases.get(department,department),function

dbpath=OUT/'medford_budget.sqlite'
if dbpath.exists():dbpath.unlink()
db=sqlite3.connect(dbpath);db.execute('PRAGMA foreign_keys=ON')
db.executescript('''
CREATE TABLE sources(fiscal_year INTEGER PRIMARY KEY, book_id INTEGER, title TEXT, source_url TEXT, pdf_library_id TEXT, pdf_status TEXT, cover_version TEXT);
CREATE TABLE categories(category_id INTEGER PRIMARY KEY,parent_id INTEGER,name TEXT,dimension TEXT,client_id TEXT,path TEXT);
CREATE TABLE versions(version_id INTEGER PRIMARY KEY,name TEXT,value_type TEXT,year INTEGER,adoption_status TEXT);
CREATE TABLE raw_statistics(source_row_id INTEGER PRIMARY KEY,fiscal_year INTEGER,version_id INTEGER,category_id INTEGER,fund_id INTEGER,department_id INTEGER,object_id INTEGER,origin_type TEXT,amount_text TEXT,raw_json TEXT);
CREATE TABLE department_crosswalk(category_id INTEGER PRIMARY KEY,original_group TEXT,original_department TEXT,comparison_department TEXT,expense_category TEXT,original_path TEXT,mapping_basis TEXT);
CREATE TABLE facts(source_row_id INTEGER PRIMARY KEY REFERENCES raw_statistics(source_row_id),fiscal_year INTEGER,version_id INTEGER REFERENCES versions(version_id),measure TEXT,period_status TEXT,fund_id INTEGER REFERENCES categories(category_id),fund_name TEXT,flow TEXT,department_category_id INTEGER REFERENCES categories(category_id),original_group TEXT,original_department TEXT,comparison_department TEXT,expense_category TEXT,object_id INTEGER REFERENCES categories(category_id),object_name TEXT,revenue_group TEXT,amount_cents INTEGER,amount_source_text TEXT);
CREATE TABLE book_series(book_id INTEGER,fiscal_year INTEGER,measure TEXT,version_id INTEGER,show_in_chart INTEGER,PRIMARY KEY(book_id,fiscal_year,measure));
CREATE TABLE department_pages(book_id INTEGER,book_year INTEGER,page_id INTEGER,page_title TEXT,department_category_id INTEGER,source_url TEXT);
CREATE TABLE reconciliation(fiscal_year INTEGER,version_id INTEGER,fund_id INTEGER,flow TEXT,detail_cents INTEGER,published_total_cents INTEGER,difference_cents INTEGER,status TEXT);
CREATE TABLE data_issues(issue_id INTEGER PRIMARY KEY,scope TEXT,issue TEXT,treatment TEXT);
CREATE INDEX facts_lookup ON facts(fund_id,fiscal_year,measure,comparison_department);
CREATE VIEW general_fund_detail AS SELECT *,CASE WHEN period_status='missing_source_budget_revenue' THEN NULL ELSE amount_cents/100.0 END AS amount FROM facts WHERE fund_id=1088668;
CREATE VIEW general_fund_totals AS SELECT fiscal_year,version_id,measure,period_status,flow,CASE WHEN period_status='missing_source_budget_revenue' THEN NULL ELSE SUM(amount_cents)/100.0 END AS amount FROM facts WHERE fund_id=1088668 GROUP BY fiscal_year,version_id,measure,period_status,flow;
CREATE VIEW general_fund_revenue AS SELECT fiscal_year,version_id,measure,period_status,revenue_group,object_id,object_name,CASE WHEN period_status='missing_source_budget_revenue' THEN NULL ELSE SUM(amount_cents)/100.0 END AS amount FROM facts WHERE fund_id=1088668 AND flow='revenue' GROUP BY fiscal_year,version_id,measure,period_status,revenue_group,object_id,object_name;
CREATE VIEW department_history AS SELECT fiscal_year,version_id,measure,period_status,comparison_department,expense_category,SUM(amount_cents)/100.0 AS amount FROM facts WHERE fund_id=1088668 AND flow='expense' GROUP BY fiscal_year,version_id,measure,period_status,comparison_department,expense_category;
CREATE VIEW department_totals AS SELECT fiscal_year,version_id,measure,period_status,comparison_department,SUM(amount_cents)/100.0 AS amount FROM facts WHERE fund_id=1088668 AND flow='expense' GROUP BY fiscal_year,version_id,measure,period_status,comparison_department;
CREATE VIEW department_year_over_year AS SELECT a.*,b.amount AS prior_year_amount,a.amount-b.amount AS change_amount,CASE WHEN b.amount!=0 THEN 100.0*(a.amount-b.amount)/b.amount END AS change_percent FROM department_totals a LEFT JOIN department_totals b ON b.fiscal_year=a.fiscal_year-1 AND b.measure=a.measure AND b.comparison_department=a.comparison_department WHERE a.period_status!='partial_or_unverified' AND (b.period_status IS NULL OR b.period_status!='partial_or_unverified');
CREATE VIEW budget_to_actual AS SELECT b.fiscal_year,b.comparison_department,b.amount AS budget_amount,a.amount AS actual_amount,a.period_status AS actual_status,CASE WHEN a.period_status='historical_actual_not_audited' THEN a.amount-b.amount END AS actual_minus_budget FROM department_totals b LEFT JOIN department_totals a ON a.fiscal_year=b.fiscal_year AND a.comparison_department=b.comparison_department AND a.measure='actual' WHERE b.measure='budget';
CREATE VIEW department_presence AS SELECT comparison_department,MIN(fiscal_year) AS first_nonzero_year,MAX(fiscal_year) AS last_nonzero_year,GROUP_CONCAT(DISTINCT original_department) AS original_names FROM facts WHERE fund_id=1088668 AND flow='expense' AND amount_cents!=0 GROUP BY comparison_department;
''')
for s in inventory['sources']:
    db.execute('INSERT INTO sources VALUES (?,?,?,?,?,?,?)',(s['fiscal_year'],s.get('book_id'),s.get('title','FY'+str(s['fiscal_year'])+' PDF budget'),s.get('source_url','https://www.medfordma.org/mayors-office/city-budget'),s.get('library_file_id'),s['pdf_status'],s.get('cover_version','not verified')))
for c in categories:db.execute('INSERT INTO categories VALUES (?,?,?,?,?,?)',(c['id'],c['parent_id'],c['name'],c['statistics_type'],c['client_id'],' / '.join(x['name'] for x in ancestry(c['id']))))
for vid in {r['version_id'] for r in raw}:
    v=versions[vid];db.execute('INSERT INTO versions VALUES (?,?,?,?,?)',(vid,v['name'],v['valueType'],v.get('year'),'not_applicable' if v['valueType']=='actual' else 'unverified_budget_book_version'))
for r in raw:db.execute('INSERT INTO raw_statistics VALUES (?,?,?,?,?,?,?,?,?,?)',(r['id'],r['year'],r['version_id'],r['category_id'],r['fund_id'],r['department_id'],r['object_id'],r['origin_type'],str(r['value']),json.dumps(r)))
leaves=[r for r in raw if r['category_id']==1088658 and all(r[k] in cats and r[k] not in parents for k in ['fund_id','department_id','object_id'])]
keys=[(r['year'],r['version_id'],r['fund_id'],r['department_id'],r['object_id']) for r in leaves]
assert len(keys)==len(set(keys)),'Duplicate analytical facts'
for d in {r['department_id'] for r in leaves}:
    group,original,comparison,function=mapping(d)
    db.execute('INSERT INTO department_crosswalk VALUES (?,?,?,?,?,?,?)',(d,group,original,comparison,function,' / '.join(x['name'] for x in ancestry(d)),'name normalization only; organizational equivalence not asserted'))
for r in leaves:
    group,original,comparison,function=mapping(r['department_id']);flow='revenue' if r['department_id']==1088660 else 'expense'
    measure='actual' if versions[r['version_id']]['valueType']=='actual' else 'budget'
    period='partial_or_unverified' if measure=='actual' and r['year']>=2026 else ('historical_actual_not_audited' if measure=='actual' else 'budget_adoption_unverified')
    if flow=='revenue' and measure=='budget' and r['year'] in [2020,2021]:period='missing_source_budget_revenue'
    op=ancestry(r['object_id']);revenue_group=op[1]['name'] if flow=='revenue' and len(op)>1 else None
    db.execute('INSERT INTO facts VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(r['id'],r['year'],r['version_id'],measure,period,r['fund_id'],cats[r['fund_id']]['name'],flow,r['department_id'],group,original,comparison,function,r['object_id'],cats[r['object_id']]['name'],revenue_group,cents(r['value']),str(r['value'])))
for f in (BASE/'raw').glob('book-*.json'):
    b=json.loads(f.read_text());bid=b['id'];nav={n['id']:n for n in json.loads((BASE/'raw'/f'nav-{bid}.json').read_text())}
    for y in json.loads((BASE/'raw'/f'years-{bid}.json').read_text()):
        if y['live'] and y['year']>=2020:
            for measure,k in [('actual','actual_version_id'),('budget','budgeted_version_id')]:
                if y.get(k):db.execute('INSERT INTO book_series VALUES (?,?,?,?,?)',(bid,y['year'],measure,y[k],int(y.get('show_actual' if measure=='actual' else 'show_budgeted',False))))
    for page in json.loads((BASE/'raw'/f'pages-{bid}.json').read_text()):
        n=nav.get(page['nav_item_id'],{});url=f"https://city-medford-ma-budget-book.cleargov.com/{bid}/{n.get('parent_name','')}/{n.get('name','')}"
        for setting in page.get('pageSettings',{}).get('expenditures_department_id',[]):db.execute('INSERT INTO department_pages VALUES (?,?,?,?,?,?)',(bid,b['year'],page['id'],page['name'],setting['value'],url))
for y,v,fund in sorted({(r['year'],r['version_id'],r['fund_id']) for r in leaves}):
    for flow,d,o in [('revenue',1088660,1088661),('expense',1088662,1088663)]:
        totals=[r for r in raw if (r['year'],r['version_id'],r['fund_id'],r['category_id'],r['department_id'],r['object_id'])==(y,v,fund,1088658,d,o)]
        detail=db.execute('SELECT SUM(amount_cents) FROM facts WHERE fiscal_year=? AND version_id=? AND fund_id=? AND flow=?',(y,v,fund,flow)).fetchone()[0]
        total=cents(totals[0]['value']) if len(totals)==1 else None
        diff=detail-total if detail is not None and total is not None else None
        status='missing_detail' if detail is None else ('no_unique_total' if total is None else ('pass' if abs(diff)<=2 else 'review'))
        db.execute('INSERT INTO reconciliation VALUES (?,?,?,?,?,?,?,?)',(y,v,fund,flow,detail,total,diff,status))
issues=[('FY2020–FY2021 budget revenue','Digital source reports zero budget revenue; usable budget revenue detail absent','Treat as missing, never as zero revenue; retain raw zero total only'),('FY2026 actuals','Current book actuals are substantially below full-year budgets; cutoff not verified','Flag partial_or_unverified; exclude from default year-over-year and variance conclusions'),('Budget adoption','Generic Budgeted series and Proposed Version covers do not prove adopted appropriations','Keep version IDs; do not label adopted until appropriation evidence is checked'),('All actuals','Budget-book actuals have not been reconciled to audited financial statements','Label historical_actual_not_audited'),('Department continuity','Name normalization does not prove identical responsibilities across years','Keep original hierarchy and book page mappings; no inferred reallocation across departments'),('Detail grain','Source provides category-level figures, not a complete general ledger account extract','Do not describe facts as transactions or account-level ledger entries'),('Unclassified source rows','Some source rows have missing dimension IDs and overlap classified totals','Exclude from additive facts; retain all rows in raw_statistics'),('Fund presentation','General Fund includes gross state aid and state/county assessments; revenue and expense totals can differ','Preserve both sides without balancing plugs; differences are not automatically operating deficits'),('Object hierarchy','Expense Objects is a leaf in the supplied object hierarchy; expense detail is in department dimension','Use expense_category for personnel/ordinary/other financing'),('Reorganizations','Building Maintenance and Facilities; PDS, Planning and Energy/Environment may reflect reorganizations','Keep separate unless supported by document evidence; department_presence is observation, not creation date')]
db.executemany('INSERT INTO data_issues(scope,issue,treatment) VALUES (?,?,?)',issues)
db.commit()
assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
assert not db.execute('PRAGMA foreign_key_check').fetchall()
gf_fail=db.execute("SELECT * FROM reconciliation WHERE fund_id=1088668 AND status='review'").fetchall()
assert not gf_fail,gf_fail
summary={'fiscal_years':[2020,2027],'raw_records':len(raw),'additive_facts':len(leaves),'general_fund_facts':db.execute('SELECT COUNT(*) FROM general_fund_detail').fetchone()[0],'general_fund_reconciliation':db.execute('SELECT status,COUNT(*) FROM reconciliation WHERE fund_id=1088668 GROUP BY status').fetchall(),'comparison_departments':db.execute('SELECT COUNT(*) FROM department_presence').fetchone()[0]}
for view in ['general_fund_totals','general_fund_revenue','department_history','department_year_over_year','budget_to_actual','department_presence','reconciliation','data_issues','department_crosswalk']:
    cur=db.execute('SELECT * FROM '+view);cols=[d[0] for d in cur.description];data=[dict(zip(cols,row)) for row in cur.fetchall()];(OUT/(view+'.json')).write_text(json.dumps(data,indent=2))
(OUT/'validation.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2));db.close()
